import neo4j from "neo4j-driver";
import { driver } from "./neo4j";
import { findMentions, readGithubData, type Pull } from "./github";

export type Evidence = {
  id: string; kind: string; title: string; text: string; author: string; date: string; url: string; files?: string[];
};
type Link = { from: string; to: string; kind: string; basis: string };

export class RepositoryError extends Error {
  constructor(message: string, readonly status: number) { super(message); }
}

export function repositoryName(input: string) {
  const match = /^(?:https:\/\/github\.com\/)?([a-z\d-]{1,39}\/[a-z\d_.-]{1,100})(?:\/)?$/i.exec(input.trim());
  const repo = match?.[1].replace(/\.git$/i, "").toLowerCase();
  if (!repo || [".", "..", ""].includes(repo.split("/")[1])) throw new RepositoryError("Enter a GitHub owner/repo or repository URL.", 400);
  return repo;
}

export async function requestGithub(path: string, token?: string) {
  const response = await fetch("https://api.github.com" + path, {
    headers: { Accept: "application/vnd.github+json", ...(token && { Authorization: "Bearer " + token }) },
    cache: "no-store", redirect: "error", signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    const quotaExhausted = response.headers.get("x-ratelimit-remaining") === "0";
    const retryAfter = response.headers.get("retry-after");
    if (response.status === 429 || (response.status === 403 && (quotaExhausted || retryAfter))) {
      const reset = quotaExhausted ? Number(response.headers.get("x-ratelimit-reset")) * 1000 : 0;
      const minutes = Math.ceil(Math.max(Number(retryAfter) / 60, (reset - Date.now()) / 60_000));
      const retry = Number.isSafeInteger(minutes) && minutes > 0
        ? `Try again in about ${minutes} ${minutes === 1 ? "minute" : "minutes"}.`
        : "Wait a few minutes before trying again.";
      const setup = token ? "" : " For public repositories, configure GITHUB_PUBLIC_READ_TOKEN on the server.";
      throw new RepositoryError("GitHub's request limit has been reached. " + retry + setup, 429);
    }
    if ([401, 403, 404].includes(response.status)) {
      throw new RepositoryError("GitHub could not confirm access to this repository or its history.", 403);
    }
    throw new RepositoryError("GitHub history is temporarily unavailable.", 502);
  }
  return response.text();
}

type PublicCacheEntry = { expiresAt: number; length: number; result: Promise<unknown> };
const publicCache = new Map<string, PublicCacheEntry>();
const PUBLIC_CACHE_TTL = 120_000;
const PUBLIC_CACHE_LIMIT = 128;
const PUBLIC_CACHE_LENGTH_LIMIT = 4 * 1024 * 1024;
let publicCacheLength = 0;

function evictPublicResponse(path: string) {
  publicCacheLength -= publicCache.get(path)?.length ?? 0;
  publicCache.delete(path);
}

function trimPublicCache() {
  while (publicCache.size > PUBLIC_CACHE_LIMIT || publicCacheLength > PUBLIC_CACHE_LENGTH_LIMIT) {
    const oldest = publicCache.keys().next();
    if (oldest.done) break;
    evictPublicResponse(oldest.value);
  }
}

async function publicGithub<T>(path: string, token?: string): Promise<T> {
  const cached = publicCache.get(path);
  if (cached && cached.expiresAt > Date.now()) return cached.result as Promise<T>;
  evictPublicResponse(path);

  const result = requestGithub(path, token).then(body => {
    const value: unknown = JSON.parse(body);
    if (publicCache.get(path) === entry) {
      if (body.length > PUBLIC_CACHE_LENGTH_LIMIT) {
        evictPublicResponse(path);
      } else {
        entry.length = body.length;
        entry.expiresAt = Date.now() + PUBLIC_CACHE_TTL;
        publicCacheLength += body.length;
        trimPublicCache();
      }
    }
    return value;
  }).catch(error => {
    if (publicCache.get(path) === entry) evictPublicResponse(path);
    throw error;
  });
  const entry: PublicCacheEntry = { expiresAt: Infinity, length: 0, result };
  publicCache.set(path, entry);
  trimPublicCache();
  return result as Promise<T>;
}

async function uncachedGithub<T>(path: string, token?: string): Promise<T> {
  return JSON.parse(await requestGithub(path, token)) as T;
}

type Thread = {
  number: number; title: string; body: string | null; user: { login: string } | null;
  created_at: string; merged_at?: string | null;
  pull_request?: { merged_at?: string | null };
};
type Comment = { id: number; body: string; user: { login: string } | null; created_at: string };
type Commit = { sha: string; author: { login: string } | null; commit: { message: string; author: { date: string } } };

async function history(repo: string, mode: "public" | "private", question: string, token?: string, throughDate?: string, files: string[] = []) {
  const root = "https://github.com/" + repo;
  const path = "/repos/" + repo;
  const records = new Map<string, Evidence>();
  function add(kind: string, id: string, title: string, text: string, author: string, date: string, url: string) {
    const record: Evidence = { id, kind, title: title.slice(0, 300), text: text.slice(0, 2800), author, date, url };
    records.set(id, record);
    return record;
  }
  const inWindow = (date: string) => !throughDate || Boolean(date && date.slice(0, 10) <= throughDate);
  function addPull(number: number, title: string, text: string, author: string, createdAt: string, mergedAt?: string | null) {
    const merged = mergedAt && inWindow(mergedAt) ? mergedAt : undefined;
    return add(merged ? "Merged PR" : "PR", "#" + number, title, text, author,
      merged ?? createdAt, root + "/pull/" + number);
  }
  const links: Link[] = [];
  const link = (from: string, to: string, kind: string, basis: string) => links.push({ from, to, kind, basis });
  const fileIds = new Set<string>();
  const publicToken = mode === "public" ? process.env.GITHUB_PUBLIC_READ_TOKEN : undefined;
  const github = <T>(endpoint: string) => mode === "public"
    ? publicGithub<T>(endpoint, publicToken)
    : uncachedGithub<T>(endpoint, token);
  type Metadata = { private: boolean; full_name: string };
  async function verifyRepository() {
    const metadata = publicToken ? await uncachedGithub<Metadata>(path, publicToken) : await github<Metadata>(path);
    if (metadata.full_name.toLowerCase() !== repo || metadata.private !== (mode === "private")) {
      throw new RepositoryError("The repository is unavailable in the selected path.", 403);
    }
  }
  function addCommit(row: Commit) {
    return add("Commit", row.sha, row.commit.message.split("\n")[0], row.commit.message,
      row.author?.login ?? "", row.commit.author.date, root + "/commit/" + row.sha);
  }

  if (mode === "public" && repo === "appfuton/futon") {
    if (files.length) await verifyRepository();
    const fixture = await readGithubData();
    for (const pull of fixture.pulls) {
      const record = addPull(pull.number, pull.title, pull.body, pull.author, pull.createdAt, pull.mergedAt);
      record.files = pull.files.slice(0, 12).map(file => file.path);
    }
    for (const issue of fixture.issues) {
      add("Issue", "#" + issue.number, issue.title, issue.body, issue.author, issue.createdAt, root + "/issues/" + issue.number);
    }
    const relevant = new Set(findMentions(question));
    for (const [index, comment] of fixture.comments.entries()) {
      if (!relevant.has(comment.parent)) continue;
      const id = "discussion:" + index;
      const commentNumber = /#(?:issuecomment|discussion_r)-?(\d+)$/.exec(comment.url)?.[0] ?? "";
      const parent = records.get("#" + comment.parent);
      if (!parent) continue;
      add("Discussion", id, "Discussion on #" + comment.parent, comment.body, comment.author,
        comment.createdAt, parent.url + commentNumber);
      link(parent.id, id, "DISCUSSION", "Comment on this thread");
    }
    for (const commit of fixture.commits.slice(0, 20)) {
      if (/^[a-f\d]{40}$/.test(commit.sha)) add("Commit", commit.sha, commit.message.split("\n")[0], commit.message,
        commit.author, commit.date, root + "/commit/" + commit.sha);
    }
    const settings = new Map<string, Pull>();
    const applied = fixture.pulls.filter(pr => pr.mergedAt && inWindow(pr.mergedAt));
    for (const pr of applied.sort((a, b) => a.mergedAt!.localeCompare(b.mergedAt!))) {
      for (const file of pr.files) {
        for (const key of file.settings.removed) {
          const prior = settings.get(file.path + ":" + key);
          if (prior && prior.number !== pr.number) link("#" + pr.number, "#" + prior.number, "SUPERSEDES",
            "Earlier PR added a preference that the later PR removed in " + file.path + ".");
          settings.delete(file.path + ":" + key);
        }
        for (const key of file.settings.added) settings.set(file.path + ":" + key, pr);
      }
    }
  } else {
    if (mode === "private" && !token) throw new RepositoryError("Provide your own read-only GitHub token for this repo.", 401);
    // Recheck visibility before using cached history with an authenticated public client.
    await verifyRepository();
    const [pulls, issues, commits] = await Promise.all([
      github<Thread[]>(path + "/pulls?state=closed&sort=updated&per_page=20"),
      github<Thread[]>(path + "/issues?state=all&sort=updated&per_page=20"),
      github<Commit[]>(path + "/commits?per_page=12"),
    ]);
    const saveThread = (row: Thread, isPull: boolean) => {
      const author = row.user?.login ?? "";
      if (isPull) {
        addPull(row.number, row.title, row.body ?? "", author, row.created_at, row.merged_at ?? row.pull_request?.merged_at);
      } else {
        add("Issue", "#" + row.number, row.title, row.body ?? "", author, row.created_at, root + "/issues/" + row.number);
      }
    };
    pulls.forEach(row => saveThread(row, true));
    issues.filter(row => !row.pull_request).forEach(row => saveThread(row, false));
    for (const row of commits) {
      if (/^[a-f\d]{40}$/.test(row.sha)) addCommit(row);
    }
    await Promise.all([...new Set(findMentions(question))].slice(0, 3).map(async number => {
      if (!records.has("#" + number)) {
        try {
          const row = await github<Thread>(path + "/issues/" + number);
          saveThread(row, Boolean(row.pull_request));
        } catch (err) {
          if (!(err instanceof RepositoryError) || err.status !== 403) throw err;
        }
      }
      const parent = records.get("#" + number);
      if (!parent) return;
      if (parent.kind.endsWith("PR")) {
        const files = await github<{filename: string}[]>(path + "/pulls/" + number + "/files?per_page=12");
        parent.files = files.map(file => file.filename);
      }
      const comments = await github<Comment[]>(path + "/issues/" + number + "/comments?per_page=5");
      for (const comment of comments) {
        const id = "discussion:" + comment.id;
        add("Discussion", id, "Discussion on #" + number, comment.body, comment.user?.login ?? "",
          comment.created_at, parent.url + "#issuecomment-" + comment.id);
        link(parent.id, id, "DISCUSSION", "Comment on this thread");
      }
    }));
  }
  if (files.length) {
    const matches = await Promise.all([...new Set(files)].map(async file => {
      const params = new URLSearchParams({ path: file, per_page: "2" });
      if (throughDate) params.set("until", throughDate + "T23:59:59Z");
      const commits = await github<Commit[]>(path + "/commits?" + params);
      return [file, commits.slice(0, 2).filter(row => /^[a-f\d]{40}$/.test(row.sha) && inWindow(row.commit.author.date))] as const;
    }));
    const commits = new Map<string, Evidence>();
    for (const [file, related] of matches) {
      for (const row of related) {
        const record = commits.get(row.sha) ?? addCommit(row);
        commits.set(row.sha, record);
        record.files = [...new Set([...(record.files ?? []), file])];
        fileIds.add(record.id);
      }
    }
    const pulls = await Promise.all([...commits].map(async ([sha, record]) => {
      const rows = await github<Thread[]>(path + "/commits/" + sha + "/pulls?per_page=1");
      return { record, pull: rows[0] };
    }));
    for (const { record, pull } of pulls) {
      if (!pull || !inWindow(pull.created_at)) continue;
      const id = "#" + pull.number;
      const existing = records.get(id);
      const source = existing ?? addPull(pull.number, pull.title, pull.body ?? "", pull.user?.login ?? "", pull.created_at, pull.merged_at);
      if (!inWindow(source.date)) continue;
      source.files = [...new Set([...(source.files ?? []), ...(record.files ?? [])])];
      fileIds.add(id);
      link(id, record.id, "REFERENCES", "GitHub associates this pull request with the commit that changed the attached file.");
    }
  }
  for (const row of records.values()) {
    if (!inWindow(row.date)) records.delete(row.id);
  }
  for (const row of records.values()) {
    for (const number of findMentions(row.text)) {
      const target = records.get("#" + number);
      if (target && target.id !== row.id) link(row.id, target.id, "REFERENCES", "Referenced in the source record");
    }
    if (row.kind !== "Merged PR" && row.kind !== "Commit") continue;
    for (const match of (row.title + "\n" + row.text).matchAll(/\b(?:supersed(?:es|ed)|replac(?:es|ed)|revert(?:s|ed))\s+(?:PR\s+)?#(\d+)\b/gi)) {
      const older = records.get("#" + match[1]);
      if (older && older.date < row.date) link(row.id, older.id, "SUPERSEDES", "Explicit replacement reference in source history");
    }
  }
  return { records: [...records.values()], links, fileIds: [...fileIds] };
}

const MATCH_EVIDENCE = `
MATCH (scope:SkillForgeChatRun)
WHERE elementId(scope) = $scope
MATCH (scope)-[:HAS_RECORD]->(r)
WITH r, size([word IN $terms WHERE toLower(r.title + " " + r.text) CONTAINS word]) AS overlap,
  CASE WHEN r.id IN $refs THEN 1000 WHEN r.id IN $fileIds THEN 100 ELSE 0 END +
  size([word IN $terms WHERE toLower(r.title) CONTAINS word]) * 4 +
  size([word IN $terms WHERE toLower(r.text) CONTAINS word]) AS score
WHERE (NOT $hasFiles AND size($refs) = 0 AND overlap >= 2 AND score >= 5) OR r.id IN $refs OR r.id IN $fileIds
ORDER BY score DESC, r.date DESC LIMIT 5
OPTIONAL MATCH (r)-[rel:DISCUSSION|REFERENCES|SUPERSEDES]-(other)
RETURN properties(r) AS record, collect(DISTINCT {kind:type(rel), basis: rel.basis,
  from: startNode(rel).id, to: endNode(rel).id, record:properties(other)})[..8] AS links
`;

export async function repositoryEvidence(repo: string, mode: "public" | "private", question: string, token?: string, contextIds: string[] = [], throughDate?: string, files: string[] = []) {
  const explicit = findMentions(question).map(number => "#" + number);
  const refs = [...new Set(explicit.length ? explicit : files.length ? [] : contextIds)];
  const { records, links, fileIds } = await history(repo, mode, [question, ...refs].join(" "), token, throughDate, files);
  const stop = new Set("why what when how this that the and for does did was are were use from with into can you explain about kyun kyon hai hua iska kya kaise kaun batao mujhe".split(" "));
  const terms = [...new Set((question.toLowerCase().match(/[a-z][a-z0-9_-]{2,}/g) ?? []).filter(word => !stop.has(word)))].slice(0, 15);
  const session = driver.session({ database: process.env.NEO4J_DATABASE || "neo4j", defaultAccessMode: neo4j.session.WRITE });
  try {
    const tx = session.beginTransaction({ timeout: 8000 });
    try {
      const scope = (await tx.run("CREATE (scope:SkillForgeChatRun) RETURN elementId(scope) AS scope")).records[0].get("scope");
      await tx.run(`MATCH (scope) WHERE elementId(scope) = $scope
        UNWIND $records AS data CREATE (scope)-[:HAS_RECORD]->(r:SkillForgeChatEvidence) SET r = data`,
      { scope, records });
      await tx.run(`MATCH (scope) WHERE elementId(scope) = $scope
        UNWIND $links AS link
        MATCH (scope)-[:HAS_RECORD]->(a {id: link.from}), (scope)-[:HAS_RECORD]->(b {id: link.to})
        FOREACH (_ IN CASE WHEN link.kind = 'SUPERSEDES' THEN [1] ELSE [] END | CREATE (a)-[:SUPERSEDES {basis:link.basis}]->(b))
        FOREACH (_ IN CASE WHEN link.kind = 'REFERENCES' THEN [1] ELSE [] END | CREATE (a)-[:REFERENCES {basis:link.basis}]->(b))
        FOREACH (_ IN CASE WHEN link.kind = 'DISCUSSION' THEN [1] ELSE [] END | CREATE (a)-[:DISCUSSION {basis:link.basis}]->(b))`,
      { scope, links });
      const matches = await tx.run(MATCH_EVIDENCE, { scope, terms, refs, fileIds, hasFiles: files.length > 0 });
      return {
        evidence: matches.records.map(row => ({
          record: row.get("record") as Evidence,
          links: (row.get("links") as (Link & { record: Evidence | null })[]).filter(item => item.record !== null),
        })),
        throughDate: throughDate || null,
        recordCount: records.length,
        matchBasis: matches.records.length ? (files.length ? "Attached file history" : explicit.length ? "Exact PR or issue number" : refs.length ? "Selected conversation sources" : "Keyword overlap in repository history") : "Insufficient evidence",
        query: MATCH_EVIDENCE.trim(),
        bundled: mode === "public" && repo === "appfuton/futon",
      };
    } finally {
      await tx.rollback();
    }
  } finally {
    await session.close();
  }
}
